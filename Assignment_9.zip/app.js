const express = require('express');
const bodyParser = require('body-parser');
const encrypt = require('mongoose-encryption');
const ejs = require('ejs');
const mongoose = require('mongoose');

var app = express();
app.set('view engine', 'ejs');
app.use(express.urlencoded({extended: true}));
app.use(express.static('public'));



mongoose.connect("mongodb://localhost:27017/secrets");
const trySchema = new mongoose.Schema({
    email : String,
    password : String,
    secrets : String
});


const secret = "thisislittlesecret.";
trySchema.plugin(encrypt,{secret: secret, encryptedFields:["password"]});

const item = mongoose.model("second", trySchema);
// const secrects = mongoose.model("secrets", trySchema);

let newSecret = "Jack Bauer is my hero."; 

app.post("/register",async function(req, res){
    try{   
        const newUser = new item({
            email : req.body.username,
            password : req.body.password
        });
        await newUser.save();
        res.redirect("/secrets");
    }
    catch(err){
        console.log(err);
    }
});

app.post("/login",async function(req, res){
      
    const username = req.body.username;
    const password = req.body.password;
    try{ 
        const foundUser = await item.findOne({email: username});
        if(foundUser){
            if(foundUser.password === password){
                res.redirect("/secrets");
            }
            else{
                res.send("Incorrect password.");
            }   
        }
        else{
            res.send("User not found.");
        }
    }
    catch(err){
        console.log(err);
    }
});
  


// app.post("/submit",async function(req, res){
//     try{
//         var secrets =  req.body.secret
//         console.log(secrets);
//         await secrets.save();
//         newSecret.push(secrets);
//         res.render("secrets",{ secretsList: newSecret});
//         // res.redirect("/secrets");
//     // res.render("secrets",{ secretsList: secrets });
//     }
//     catch(err){
//         console.log(err);
//     }
// }
// );


// ✅ Add new secret to array, then redirect


// app.post("/submit", (req, res) => {
//     const submittedSecret = req.body.secret?.trim(); // Clean input
//     if (submittedSecret) {
//       newSecret = submittedSecret; // Update the value
//     }
//     res.redirect("/secrets");
//   });
  




// route defined  

app.get("/",function(req, res){
    res.render("home");
});

app.get("/login",function(req, res){
    res.render("login");
});

app.get("/register",function(req, res){
    res.render("register");
});
app.get("/secrets",(req, res) => res.render("secrets",{secret: newSecret}));



app.get("/submit",(req, res) => res.render("submit"));
app.get("/logout",(req, res) => res.render("home"));




app.post("/submit", (req, res) => {
    newSecret = req.body.secret;
    res.render("secrets",{secret: newSecret});
    
});

app.listen(3000,() => {
    console.log("Server started on port 3000");
});